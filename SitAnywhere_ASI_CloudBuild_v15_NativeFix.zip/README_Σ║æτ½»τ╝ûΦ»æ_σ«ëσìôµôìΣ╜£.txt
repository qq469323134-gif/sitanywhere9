SitAnywhere ASI - GitHub Actions 云端 Windows 编译包

此包将 v8 源码工程放入 GitHub Actions 工作流。GitHub 的 windows-2022 托管运行器提供 Windows x64 环境；工作流调用 MSBuild 编译，并将 SitAnywhere.asi 与 SitAnywhere.ini 上传为构建产物。

安卓手机操作步骤：
1. 在浏览器打开 https://github.com 并登录/注册。
2. 新建一个仓库。建议先选 Private（私有）以免公开源码；私有仓库的 Actions 使用量受账户额度限制。若选 Public，标准托管运行器的使用规则不同，且仓库源码公开。
3. 将本压缩包解压，把解压后最外层的 .github 文件夹、SitAnywhere_ASI_v8 文件夹和 README 文件上传到仓库根目录。注意：.github 必须位于仓库根目录，不能放在 SitAnywhere_ASI_v8 里面。
4. 打开仓库的 Actions 页面，选择 Build SitAnywhere ASI，然后点 Run workflow。
5. 等待任务完成。绿色成功后打开该次运行，在 Artifacts 区域下载 SitAnywhere-ASI-x64.zip。
6. 解压产物，检查是否同时有 SitAnywhere.asi 和 SitAnywhere.ini。把二者放到 GTA5 主目录（与 ScriptHookV.dll 同一目录）。

失败处理：
- 若 Actions 显示红色失败，请打开失败任务，把最前面的 MSBuild error 和相关日志复制回来；不要反复运行猜测。
- 如果提示 Windows SDK / v143 不存在，需要根据日志调整 runner 或工程工具集。
- 如果成功产物中没有 .asi，不要安装其他文件冒充 ASI。

重要说明：
- 此工作流文件本身尚未在用户仓库中运行，不能声称云端编译已经成功。
- 源码仍未经过 GTA5 实机测试；成功编译只证明生成了 PE DLL 格式的 .asi 文件，不证明游戏内动画、输入映射或行为完全正确。
- 项目不包含 ScriptHookV.dll；游戏主目录必须另行安装与游戏版本匹配的 ScriptHookV。
