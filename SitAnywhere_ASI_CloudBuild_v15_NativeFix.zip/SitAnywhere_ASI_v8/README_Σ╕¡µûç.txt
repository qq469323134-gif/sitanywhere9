Sit Anywhere ASI v8（源码工程）

目标：Windows PC 版 GTA5 单机，原生 x64 ASI，不使用 ScriptHookVDotNet。

本版处理：
1. 统一工程目录名称为 SitAnywhere_ASI_v8（此前 v7 压缩包内部目录仍叫 v6，容易混淆）。
2. 保留键盘 E 的 ScriptHookV keyboardHandler 独立监听。
3. 保留手柄 LB+RB 组合上升沿检测（默认控制编号 37、44，可在 ini 修改）。
4. 坐下时检测跳跃控制 22（刚按下）和冲刺控制 21（按住）以起身。
5. 按用户提供的 ScriptHookV 3889.0 / 1158.13 DLL 导出表核对动态解析的导出名称。
6. 按用户提供的 SDK main.h 核对函数原型：keyboardHandlerRegister/Unregister、scriptRegister/Unregister、scriptWait、nativeInit、nativePush64、nativeCall。
7. 将 INI 读取的控制编号显式转换，消除对应的有符号/无符号编译警告。
8. 不依赖 ScriptHookV.lib；使用 GetProcAddress 解析 ScriptHookV.dll 导出函数。

编译：
需要 Windows x64、Visual Studio 2022、Desktop development with C++、MSBuild。
在此目录运行 build_windows_x64.bat。预期输出 bin\SitAnywhere.asi。

安装：
把 SitAnywhere.asi 和 SitAnywhere.ini 放入 GTA5 主目录（与 ScriptHookV.dll 同目录）。

重要限制：
- 当前工作环境没有 Windows MSVC/Windows SDK，故未能生成或验证 .asi 二进制。
- 当前仅完成源代码静态语法检查（使用临时 Windows API 声明桩），不等同于 MSVC 编译。
- 尚未在 GTA5 实机测试坐姿动画、按键冲突、手柄映射或角色状态恢复。
- LB/RB 控制映射依赖当前游戏输入配置，可能需要按实际手柄映射调整。
- 本项目是依据已知功能重新实现的原生 ASI，并非原始 .NET DLL 的反编译或逐行复刻。
