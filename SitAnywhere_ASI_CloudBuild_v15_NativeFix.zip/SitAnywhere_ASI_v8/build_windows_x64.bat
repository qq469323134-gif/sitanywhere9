@echo off
setlocal
where msbuild >nul 2>nul
if not errorlevel 1 goto build
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if exist "%VSWHERE%" (
  for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.Component.MSBuild -find MSBuild\**\Bin\MSBuild.exe`) do set "MSBUILD=%%i"
)
if not defined MSBUILD (
  echo ERROR: MSBuild not found. Install Visual Studio 2022 with Desktop development with C++.
  exit /b 1
)
"%MSBUILD%" SitAnywhere.vcxproj /m /p:Configuration=Release /p:Platform=x64
goto check
:build
msbuild SitAnywhere.vcxproj /m /p:Configuration=Release /p:Platform=x64
:check
if errorlevel 1 exit /b 1
if not exist bin\SitAnywhere.asi exit /b 2
echo Build complete: bin\SitAnywhere.asi
endlocal
