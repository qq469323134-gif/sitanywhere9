#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <cstdint>
#include <cstring>

// ScriptHookV API resolved by exact x64 decorated export names.
using ScriptMainFn = void(*)();
using ScriptRegisterFn = void(__cdecl*)(HMODULE, ScriptMainFn);
using ScriptUnregisterFn = void(__cdecl*)(HMODULE);
using ScriptWaitFn = void(__cdecl*)(DWORD);
using NativeInitFn = void(__cdecl*)(uint64_t);
using NativePush64Fn = void(__cdecl*)(uint64_t);
using NativeCallFn = uint64_t*(__cdecl*)();
using KeyboardHandlerFn = void(__cdecl*)(DWORD, WORD, BYTE, BOOL, BOOL, BOOL, BOOL);
using KeyboardRegisterFn = void(__cdecl*)(KeyboardHandlerFn);
using KeyboardUnregisterFn = void(__cdecl*)(KeyboardHandlerFn);

static HMODULE g_module = nullptr;
static ScriptRegisterFn g_scriptRegister = nullptr;
static ScriptUnregisterFn g_scriptUnregister = nullptr;
static ScriptWaitFn g_scriptWait = nullptr;
static NativeInitFn g_nativeInit = nullptr;
static NativePush64Fn g_nativePush64 = nullptr;
static NativeCallFn g_nativeCall = nullptr;
static KeyboardRegisterFn g_keyboardRegister = nullptr;
static KeyboardUnregisterFn g_keyboardUnregister = nullptr;
static bool g_sitting = false;
static bool g_savedPosition = false;
static float g_originalX = 0.0f, g_originalY = 0.0f, g_originalZ = 0.0f;
// Keep the ped root/seat height unchanged; only solve the legs toward the ground.
static bool g_comboWasDown = false;
static volatile LONG g_keyboardSitPressed = 0;
static DWORD g_sitVirtualKey = 0x45; // VK_E
static int g_lbControl = 37;  // INPUT_SELECT_WEAPON: LB
static int g_rbControl = 44;  // INPUT_COVER: RB
static char g_iniPath[MAX_PATH] = {};

static constexpr uint64_t H_PLAYER_PED_ID         = 0xD80958FC74E988A6ULL;
static constexpr uint64_t H_IS_CONTROL_PRESSED    = 0xF3A21BCD95725A4AULL;
static constexpr uint64_t H_IS_CONTROL_JUST_PRESSED = 0x580417101DDB492FULL;
static constexpr uint64_t H_IS_PED_IN_ANY_VEHICLE = 0x997ABD671D25CA0BULL;
static constexpr uint64_t H_REQUEST_ANIM_DICT     = 0xD3BD40951412FEF6ULL;
static constexpr uint64_t H_HAS_ANIM_DICT_LOADED  = 0xD031A9162D01088CULL;
static constexpr uint64_t H_TASK_PLAY_ANIM        = 0xEA47FE3719165B94ULL;
static constexpr uint64_t H_CLEAR_PED_TASKS       = 0xE1EF3C1216AFF2CDULL;
static constexpr uint64_t H_SET_IK_TARGET         = 0xC32779C16FCEECD9ULL;
static constexpr uint64_t H_GET_PED_BONE_COORDS   = 0x17C07FC640E86B4EULL;
static constexpr uint64_t H_GET_GROUND_Z          = 0xC906A7DAB05C8D2BULL;
static constexpr uint64_t H_SET_PED_CAN_LEG_IK     = 0x73518ECE2485412BULL;
static constexpr uint64_t H_GET_ENTITY_COORDS      = 0x3FEF770D40960D5AULL;
static constexpr uint64_t H_SET_ENTITY_COORDS_NO_OFFSET = 0x239A3351AC1DA385ULL;
static constexpr int BONE_LEFT_FOOT = 0x3779;
static constexpr int BONE_RIGHT_FOOT = 0xCC4D;
static constexpr int IK_PART_LEFT_LEG = 5;
static constexpr int IK_PART_RIGHT_LEG = 6;

static void __cdecl OnKeyboard(DWORD key, WORD, BYTE, BOOL, BOOL, BOOL wasDownBefore, BOOL isUpNow)
{
    // Only accept a fresh key-down event; this keeps a held key from toggling repeatedly.
    if (key == g_sitVirtualKey && !isUpNow && !wasDownBefore)
        InterlockedExchange(&g_keyboardSitPressed, 1);
}

static bool ResolveScriptHook()
{
    HMODULE shv = GetModuleHandleW(L"ScriptHookV.dll");
    if (!shv) return false;
    g_scriptRegister = reinterpret_cast<ScriptRegisterFn>(GetProcAddress(shv, "?scriptRegister@@YAXPEAUHINSTANCE__@@P6AXXZ@Z"));
    g_scriptUnregister = reinterpret_cast<ScriptUnregisterFn>(GetProcAddress(shv, "?scriptUnregister@@YAXPEAUHINSTANCE__@@@Z"));
    g_scriptWait = reinterpret_cast<ScriptWaitFn>(GetProcAddress(shv, "?scriptWait@@YAXK@Z"));
    g_nativeInit = reinterpret_cast<NativeInitFn>(GetProcAddress(shv, "?nativeInit@@YAX_K@Z"));
    g_nativePush64 = reinterpret_cast<NativePush64Fn>(GetProcAddress(shv, "?nativePush64@@YAX_K@Z"));
    g_nativeCall = reinterpret_cast<NativeCallFn>(GetProcAddress(shv, "?nativeCall@@YAPEA_KXZ"));
    g_keyboardRegister = reinterpret_cast<KeyboardRegisterFn>(GetProcAddress(shv, "?keyboardHandlerRegister@@YAXP6AXKGEHHHH@Z@Z"));
    g_keyboardUnregister = reinterpret_cast<KeyboardUnregisterFn>(GetProcAddress(shv, "?keyboardHandlerUnregister@@YAXP6AXKGEHHHH@Z@Z"));
    return g_scriptRegister && g_scriptUnregister && g_scriptWait && g_nativeInit &&
           g_nativePush64 && g_nativeCall && g_keyboardRegister && g_keyboardUnregister;
}

static void Push(uint64_t value) { g_nativePush64(value); }
static uint64_t Call0(uint64_t hash)
{
    g_nativeInit(hash);
    uint64_t* result = g_nativeCall();
    return result ? *result : 0;
}
static uint64_t Call1(uint64_t hash, uint64_t a)
{
    g_nativeInit(hash); Push(a);
    uint64_t* result = g_nativeCall();
    return result ? *result : 0;
}
static uint64_t Call2(uint64_t hash, uint64_t a, uint64_t b)
{
    g_nativeInit(hash); Push(a); Push(b);
    uint64_t* result = g_nativeCall();
    return result ? *result : 0;
}
static uint64_t FloatBits(float value);
static uint64_t Call5(uint64_t hash, uint64_t a, uint64_t b, uint64_t c, uint64_t d, uint64_t e)
{
    g_nativeInit(hash); Push(a); Push(b); Push(c); Push(d); Push(e);
    uint64_t* result = g_nativeCall();
    return result ? *result : 0;
}
static uint64_t Call10(uint64_t hash, const uint64_t* a)
{
    g_nativeInit(hash);
    for (int i = 0; i < 10; ++i) Push(a[i]);
    uint64_t* result = g_nativeCall();
    return result ? *result : 0;
}
static bool GetFootWorldPosition(int ped, int bone, float& x, float& y, float& z)
{
    // GET_PED_BONE_COORDS returns a Vector3 in the native result buffer.
    const uint64_t args[5] = { static_cast<uint32_t>(ped), static_cast<uint32_t>(bone), FloatBits(0.0f), FloatBits(0.0f), FloatBits(0.0f) };
    g_nativeInit(H_GET_PED_BONE_COORDS);
    for (uint64_t v : args) Push(v);
    uint64_t* result = g_nativeCall();
    if (!result) return false;
    // Vector3 return values are three contiguous 32-bit floats, not three
    // 64-bit slots. Reading result[1]/result[2] as uint64_t skips components.
    const float* vector = reinterpret_cast<const float*>(result);
    x = vector[0];
    y = vector[1];
    z = vector[2];
    return true;
}
static bool GetGroundZ(float x, float y, float probeZ, float& groundZ)
{
    BOOL found = FALSE;
    // Native signature has SIX parameters: x, y, z, outGroundZ, ignoreWater, p5.
    const uint64_t args[6] = { FloatBits(x), FloatBits(y), FloatBits(probeZ), reinterpret_cast<uint64_t>(&groundZ), 0, 0 };
    g_nativeInit(H_GET_GROUND_Z);
    for (uint64_t v : args) Push(v);
    uint64_t* result = g_nativeCall();
    found = result && (*result != 0);
    return found != FALSE;
}
static void ApplyFootIK(int ped)
{
    float x = 0.0f, y = 0.0f, z = 0.0f, groundZ = 0.0f;
    const int bones[2] = { BONE_LEFT_FOOT, BONE_RIGHT_FOOT };
    const int parts[2] = { IK_PART_LEFT_LEG, IK_PART_RIGHT_LEG };
    for (int i = 0; i < 2; ++i)
    {
        if (!GetFootWorldPosition(ped, bones[i], x, y, z)) continue;
        if (!GetGroundZ(x, y, z + 1.0f, groundZ)) continue;
        // IK targets are refreshed every frame; target is just above ground with finite blend times.
        const uint64_t args[10] = { static_cast<uint32_t>(ped), static_cast<uint32_t>(parts[i]), 0, static_cast<uint32_t>(-1), FloatBits(x), FloatBits(y), FloatBits(groundZ + 0.01f), 0, 100, 100 };
        Call10(H_SET_IK_TARGET, args);
    }
}
static uint64_t FloatBits(float value)
{
    uint32_t bits = 0;
    static_assert(sizeof(bits) == sizeof(value), "float must be 32-bit");
    std::memcpy(&bits, &value, sizeof(bits));
    return bits;
}
static bool NativeBool(uint64_t value) { return value != 0; }
static bool GetEntityPosition(int entity, float& x, float& y, float& z)
{
    const uint64_t args[2] = { static_cast<uint32_t>(entity), 0 };
    g_nativeInit(H_GET_ENTITY_COORDS);
    Push(args[0]); Push(args[1]);
    uint64_t* result = g_nativeCall();
    if (!result) return false;
    // GET_ENTITY_COORDS also returns a packed Vector3 (three adjacent floats).
    const float* vector = reinterpret_cast<const float*>(result);
    x = vector[0];
    y = vector[1];
    z = vector[2];
    return true;
}
static void SetEntityPosition(int entity, float x, float y, float z)
{
    g_nativeInit(H_SET_ENTITY_COORDS_NO_OFFSET);
    Push(static_cast<uint32_t>(entity));
    Push(FloatBits(x)); Push(FloatBits(y)); Push(FloatBits(z));
    Push(0); Push(0); Push(1);
    g_nativeCall();
}
// No whole-ped Z offset: lowering the root also lowers the pelvis and torso.
// Foot placement is handled independently by ApplyFootIK().
static void ApplySeatDrop(int) {}

static void StandUp(int ped)
{
    if (g_savedPosition)
    {
        SetEntityPosition(ped, g_originalX, g_originalY, g_originalZ);
        g_savedPosition = false;
    }
    Call2(H_SET_PED_CAN_LEG_IK, static_cast<uint32_t>(ped), 0);
    Call1(H_CLEAR_PED_TASKS, static_cast<uint32_t>(ped));
    g_sitting = false;
}

static void SitDown(int ped)
{
    g_savedPosition = GetEntityPosition(ped, g_originalX, g_originalY, g_originalZ);
    // Explicitly enable leg IK so the per-frame foot targets can be solved.
    Call2(H_SET_PED_CAN_LEG_IK, static_cast<uint32_t>(ped), 1);
    static const char* dict = "amb@code_human_in_bus_passenger_idles@male@sit@idle_a";
    static const char* anim = "idle_a";
    Call1(H_REQUEST_ANIM_DICT, reinterpret_cast<uint64_t>(dict));
    for (int i = 0; i < 100; ++i)
    {
        if (NativeBool(Call1(H_HAS_ANIM_DICT_LOADED, reinterpret_cast<uint64_t>(dict)))) break;
        g_scriptWait(10);
    }
    if (!NativeBool(Call1(H_HAS_ANIM_DICT_LOADED, reinterpret_cast<uint64_t>(dict)))) return;

    // TASK_PLAY_ANIM: ped, dict, name, speed, speedMultiplier, duration, flag,
    // playbackRate, lockX, lockY, lockZ.
    g_nativeInit(H_TASK_PLAY_ANIM);
    Push(static_cast<uint32_t>(ped));
    Push(reinterpret_cast<uint64_t>(dict));
    Push(reinterpret_cast<uint64_t>(anim));
    Push(FloatBits(8.0f));
    Push(FloatBits(-8.0f));
    Push(static_cast<uint32_t>(-1));
    Push(1); // loop
    Push(FloatBits(1.0f));
    Push(0); Push(0); Push(0);
    g_nativeCall();
    g_sitting = true;
}

static void ScriptMain()
{
    while (true)
    {
        g_scriptWait(0);
        const int ped = static_cast<int>(Call0(H_PLAYER_PED_ID));
        if (ped == 0) continue;

        const bool inVehicle = NativeBool(Call2(H_IS_PED_IN_ANY_VEHICLE, static_cast<uint32_t>(ped), 0));
        const bool keyboardToggle = InterlockedExchange(&g_keyboardSitPressed, 0) != 0;
        const bool comboDown = NativeBool(Call2(H_IS_CONTROL_PRESSED, 0, static_cast<uint32_t>(g_lbControl))) &&
                               NativeBool(Call2(H_IS_CONTROL_PRESSED, 0, static_cast<uint32_t>(g_rbControl)));
        const bool comboToggle = comboDown && !g_comboWasDown;
        g_comboWasDown = comboDown;
        const bool toggle = keyboardToggle || comboToggle;

        // Read input controls directly: jumping is control 22, sprint is control 21.
        const bool jumpPressed = NativeBool(Call2(H_IS_CONTROL_JUST_PRESSED, 0, 22));
        const bool sprintHeld = NativeBool(Call2(H_IS_CONTROL_PRESSED, 0, 21));
        if (g_sitting)
        {
            if (toggle || jumpPressed || sprintHeld || inVehicle) StandUp(ped);
            else { ApplySeatDrop(ped); ApplyFootIK(ped); }
        }
        else if (toggle && !inVehicle)
        {
            SitDown(ped);
        }
    }
}

static void MakeIniPath(HMODULE module)
{
    GetModuleFileNameA(module, g_iniPath, MAX_PATH);
    char* dot = std::strrchr(g_iniPath, '.');
    if (dot)
    {
        const size_t remaining = MAX_PATH - static_cast<size_t>(dot - g_iniPath);
        strcpy_s(dot, remaining, ".ini");
    }
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH)
    {
        g_module = hModule;
        DisableThreadLibraryCalls(hModule);
        MakeIniPath(hModule);
        g_sitVirtualKey = static_cast<DWORD>(GetPrivateProfileIntA("Keys", "SitVirtualKey", 0x45, g_iniPath));
        g_lbControl = static_cast<int>(GetPrivateProfileIntA("Controller", "LeftShoulderControl", 37, g_iniPath));
        g_rbControl = static_cast<int>(GetPrivateProfileIntA("Controller", "RightShoulderControl", 44, g_iniPath));
        if (g_sitVirtualKey < 1 || g_sitVirtualKey > 255) g_sitVirtualKey = 0x45;
        if (g_lbControl < 0 || g_lbControl > 360) g_lbControl = 37;
        if (g_rbControl < 0 || g_rbControl > 360) g_rbControl = 44;
        if (ResolveScriptHook())
        {
            g_keyboardRegister(OnKeyboard);
            g_scriptRegister(hModule, ScriptMain);
        }
    }
    else if (reason == DLL_PROCESS_DETACH)
    {
        if (g_keyboardUnregister) g_keyboardUnregister(OnKeyboard);
        if (g_scriptUnregister) g_scriptUnregister(hModule);
    }
    return TRUE;
}
